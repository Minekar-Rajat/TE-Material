module macro_pass_1 {
}